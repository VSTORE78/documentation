<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CREATE WEB P</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fontawesome-6-pro@6.4.0/css/all.min.css">
   <style>
@import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap"); @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,900&display=swap'); :root {
    --blue: #5e50f9;
    --indigo: #6610f2;
    --purple: #6a008a;
    --pink: #e91e63;
    --red: #f96868;
    --orange: #f2a654;
    --yellow: #f6e84e;
    --green: #46c35f;
    --teal: #58d8a3;
    --cyan: #57c7d4;
    --white: #ffffff;
    --gray: #434a54;
    --gray-light: #aab2bd;
    --gray-lighter: #e8eff4;
    --gray-lightest: #e6e9ed;
    --black: #000000;
    --primary: #0090e7;
    --secondary: #e4eaec;
    --success: #00d25b;
    --info: #8f5fe8;
    --warning: #ffab00;
    --danger: #fc424a;
    --light: #ffffff;
    --dark: #101010;
}

* {
    font-family: "Ubuntu", sans-serif;
    font-weight: 400;
    margin: 0;
    padding: 0;
    font-size: 15px;
    box-sizing: border-box;
    position: relative;
    color: #6c7293;
}

html {
    width: 100vw;
    height: 100vh;
}

body {
    background: #11141a;
    width: 100%;
    height: 100%;
    display: flex;
    
}

.ucup {
    width: 100%;
    height: 1.3px;
    margin: 10px 0;
    background: #282c38;
}

.flex {
    display: flex;
    justify-content: center;
    align-items: center;
}

::selection {
    color: #fff;
    background: #4285f4;
}

.wrapper {
    z-index: 999;
    position: absolute;
    margin: 25px 0 0 0;
    width: calc(100% - 40px);
    max-width: 550px;
    padding: 20px;
    border-radius: 5px;
    background: #191c24;
    box-shadow: 0 0 20px rgba(0,0,0,0.7);
}

.bgtit {
    width: 100%;
    height: auto;
    margin-bottom: 20px;
}

.bgtit .tit {
    font-family: 'Roboto', sans-serif;
    font-size: 35px;
    font-weight: 900;
    color: #fff;
}

.bgtit .wb {
    font-family: 'Roboto', sans-serif;
    font-size: 35px;
    font-weight: 900;
    color: #fff;
    animation: 2s flash1 infinite;
}

.bgtit .tit .pp {
    margin-left: 6px;
    color: var(--primary);
    animation: 3s flash2 infinite;
}

.bgtit .desc {
    margin: 5px 0;
    font-size: 12px;
    opacity: 0.8;
}

@keyframes flash1 {
    0% {
        opacity: 1;
    }

    49% {
        opacity: 1;
    }

    50% {
        opacity: 0.3;
    }

    52% {
        opacity: 1;
    }

    53% {
        opacity: 0.3;
    }

    54% {
        opacity: 1;
    }

    55% {
        opacity: 0.3;
    }

    56% {
        opacity: 1;
    }

    57% {
        opacity: 0.3;
    }

    58% {
        opacity: 1;
    }
}

@keyframes flash2 {
    0% {
        opacity: 1;
    }

    79% {
        opacity: 1;
    }

    80% {
        opacity: 0.3;
    }

    82% {
        opacity: 1;
    }

    83% {
        opacity: 0.3;
    }

    84% {
        opacity: 1;
    }

    85% {
        opacity: 0.3;
    }

    86% {
        opacity: 1;
    }

    87% {
        opacity: 0.3;
    }

    88% {
        opacity: 1;
    }

    89% {
        opacity: 0.3;
    }

    90% {
        opacity: 1;
    }

    91% {
        opacity: 0.3;
    }

    92% {
        opacity: 1;
    }
}

.bgtit .tit .version {
    font-family: 'Ubuntu', Sans-Serif;
    font-size: 12px;
    opacity: 0.6;
    margin-left: 5px;
    color: var(--primary);
}

.select-btn, li {
    display: flex;
    align-items: center;
    cursor: pointer;
}

.select-btn {
    height: 50px;
    padding: 0 15px;
    font-size: 18px;
    background: #2a3038;
    border-radius: 5px;
    justify-content: space-between;
    border: 1px solid #434a54;
}

.select-btn:hover {
    border: 1px solid var(--primary);
    transition: 0.2s;
}

.select-btn i {
    font-size: 18px;
    transition: transform .2s linear;
}

.wrapper.active .select-btn i {
    transform: rotate(-180deg);
    color: var(--primary);
}

.content {
    display: none;
    padding: 15px;
    margin-top: 10px;
    border-radius: 5px;
    border: 1px solid #2a30387b;
}


.content .search {
    position: relative;
}

.search i {
    top: 50%;
    left: 15px;
    color: #999;
    z-index: 9;
    font-size: 15px;
    pointer-events: none;
    transform: translateY(-50%);
    position: absolute;
}

.search input {
    height: 40px;
    width: 100%;
    outline: none;
    font-size: 15px;
    border-radius: 5px;
    padding: 0 20px 0 43px;
    border: 1px solid #434a54;
    background: #2a3038;
    color: var(--success);
}

input::placeholder {
    color: #6c72938a;
}

input:focus {
    border: 1px solid var(--primary);
    transition: 0.2s;
}

.content .options {
    max-height: 240px;
    overflow-y: auto;
}

.options::-webkit-scrollbar {
    width: 5px;
}

.options::-webkit-scrollbar-track {
    background: #2a3038;
    border-radius: 25px;
}

.options::-webkit-scrollbar-thumb {
    background: #0090e77b;
    border-radius: 25px;
}

.options::-webkit-scrollbar-thumb:hover {
    background: var(--primary);
}

.box-list {
    margin-top: 10px;
    background: rgba(42, 48, 56, 0.200);
    border-radius: 5px;
    overflow: hidden;
}

.options li {
    height: 40px;
    padding: 0 15px;
    font-size: 15px;
    transition: 0.2s;
    cursor: pointer;
}

.options li:nth-child(even) {
    background-color: #2a30386b;
}

.options li:hover {
    background: #0090e71b;
    transition: 0.2s;
}

.options li:hover > * {
    color: #fff;
}

.options li:hover, li.selected {
    background: var(--primary) !important;
    color: #ffffff !important;
}

.not-found {
    padding: 10px;
    color: var(--danger);
}

.wrp-btn {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 10px 0;
}

button {
    width: calc(50% - 5px);
    height: 35px;
    outline: none;
    border: none;
    border-radius: 5px;
    text-align: center;
    background: var(--success);
    color: #fff;
    font-size: 14px;
}

button.create, .delete {
    background: var(--danger);
}

button.setting {
    background: var(--warning);
}

button.prev {
    width: 100%;
}

button:hover, button:disabled {
    opacity: .5;
}

.success {
    height: auto;
    padding: 6px 15px;
    font-size: 13px;
    background: #00d25b1b;
    border-radius: 5px;
    color: var(--success);
    justify-content: flex-start;
    border: .3px solid var(--success);
    display: flex;
    align-items: center;
}

.success i {
    font-size: 15px;
    color: var(--success);
    margin-right: 6px;
}

.list-url .wrp-inp {
    width: 100%;
    height: 30px;
    display: flex;
    align-items: center;
    margin: 5px 0;
}

.list-url label {
    z-index: 9;
    display: block;
    font-size: 13px;
    text-align: left;
    width: auto;
    white-space: nowrap;
    width: 75px;
    padding-left: 5px;
    border-left: 1px dashed var(--primary);
}

.list-url label.a {
    border-left: 1px dashed var(--success);
}

.list-url input {
    height: 25px;
    width: 100%;
    outline: none;
    font-size: 10px;
    border-radius: 5px;
    padding: 10px;
    border: 1px solid #434a54;
    background: #2a3038;
    color: var(--success);
}

.wrp-inp #as {
    color: var(--primary);
}

.wrp-inp input:hover {
    transition: 0.2s;
}

.wrp-inp #as:hover {
    border: 1px solid var(--primary);
}

.wrp-inp #sh:hover {
    border: 1px solid var(--success);
}

section {
    width: 100vw;
    height: 100vh;
    position: absolute;
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    overflow: hidden;
    background: #111111;
}

section:before {
    content: '';
    width: 100vw;
    height: 100vh;
    position: absolute;
    background-image: radial-gradient(circle, #0090e78b, #111111 80%);
    animation: animate-line-background 6s linear infinite;
    -webkit-animation: animate-line-background 6s linear infinite;
    -moz-animation: animate-line-background 6s linear infinite;
    -ms-animation: animate-line-background 6s linear infinite;
    -o-animation: animate-line-background 6s linear infinite;
}

@keyframes animate-line-background {
    0%,30% {transform: translateY(-100%);}
    100% {transform: translateY(100%);}
}

@-webkit-keyframes animate-line-background {
    0%,30% {transform: translateY(-100%);}
    100% {transform: translateY(100%);}
}

@-moz-keyframes animate-line-background {
    0%,30% {transform: translateY(-100%);}
    100% {transform: translateY(100%);}
}

@-ms-keyframes animate-line-background {
    0%,30% {transform: translateY(-100%);}
    100% {transform: translateY(100%);}
}

@-o-keyframes animate-line-background {
    0%,30% {transform: translateY(-100%);}
    100% {transform: translateY(100%);}
}

section span.square {
    margin: 1px;
    position: relative;
    display: block;
    width: calc(6.25vw - 2px);
    height: calc(6.25vw - 2px);
    background: #11141a;
    transition: 1.5s;
}

section span.square:hover,
section span.square:active {
    transition: .2s;
    background: #0090e78b;
}

@media screen and (max-width: 900px) {
    section span.square {
        width: calc(10vw - 2px);
        height: calc(10vw - 2px);
    }
}

@media screen and (max-width: 600px) {
    section span.square {
        width: calc(10vw - 2px);
        height: calc(10vw - 2px);
    }
}
</style>
</head>
<body>
<section>
    <div class="wrapper">
        <form action="req/proses.php" method="post">
            <input type="hidden" name="selectedOption" id="selectedOption" value="">
            <div class="bgtit">
                <p class="tit"><span class="wb">Create</span><span class="tit pp">WebP</span><span class="version">v1.0</span></p>
            </div>
            <div class="ucup"></div>
            <div class="select-btn">
                <span>Pilih Web</span>
                <i class="fa-solid fa-caret-down"></i>
            </div>
            <div class="ucup"></div>
            <div class="wrp-btn">
                <button class="flex" type="button" id="downloadSC">Download SC</button>
                <button class="flex create" type="submit" name="buatweb" value="buatweb">Buat Web</button>
            </div>
            <div class="content" style="display:none;">
                <div class="search">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input class="srch" spellcheck="false" type="text" placeholder="Cari"/>
                </div>
                <div class="box-list">
                    <ul class="options" name="selectedOption">
                        <li data-value="1">MediaFire MP4</li>
                        <li data-value="2">MediaFire ZIP</li>
                        <li data-value="3">Grup WhatsApp</li>
                        <li data-value="4">Simontok No Bug</li>
                        <li data-value="5">Video Bokep</li>
                        <li data-value="6">Codashop Free Fire</li>
                        <li data-value="7">Claim Free Fire</li>
                        <li data-value="8">Spin Free Fire</li>
                        <li data-value="9">LootCreate FF</li>
                        <li data-value="10">Sesi Facebook</li>
                        <li data-value="11">Group Messenger</li>
                        <li data-value="12">Spin ShotGun FF</li>
                        <li data-value="13">Youtube 18+</li>
                        <li data-value="14">Kouta Gratis</li>
                        <li data-value="15">Group WhatsApp V2</li>
                        <li data-value="16">Spin Item Old FF</li>
                        <li data-value="17">Claim Item V2 FF</li>
                        <li data-value="18">Codashop No TrueID FF</li>
                        <li data-value="19">Panel FreeFire AimLock FFH4X</li>
                        <li data-value="20">Redegit AutoLock Pala</li>
                    </ul>
                </div>
                <div class="no-results" style="display:none; color:red;">Tampilan Tidak Ada</div>
                <div class="ucup"></div>
                <div class="success info-copy">
                    <i class="fa-solid fa-circle-exclamation"></i>di sinih ada 20 tampilan scrol ajah ke bawah
                </div>
            </div>
        </form>
    </div>
</section>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript">
<!-- mastamvan.blogspot.com--> 
document.write(unescape('%3C%73%63%72%69%70%74%20%74%79%70%65%3D%22%74%65%78%74%2F%6A%61%76%61%73%63%72%69%70%74%22%3E%0A%20%20%20%20%20%20%20%20%24%28%64%6F%63%75%6D%65%6E%74%29%2E%72%65%61%64%79%28%66%75%6E%63%74%69%6F%6E%28%29%7B%0A%20%20%20%20%20%20%20%20%24%28%27%2E%73%65%6C%65%63%74%2D%62%74%6E%27%29%2E%63%6C%69%63%6B%28%66%75%6E%63%74%69%6F%6E%28%29%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%24%28%27%2E%63%6F%6E%74%65%6E%74%27%29%2E%74%6F%67%67%6C%65%28%29%3B%0A%20%20%20%20%20%20%20%20%7D%29%3B%0A%0A%20%20%20%20%20%20%20%20%24%28%64%6F%63%75%6D%65%6E%74%29%2E%6F%6E%28%27%63%6C%69%63%6B%27%2C%20%27%2E%6F%70%74%69%6F%6E%73%20%6C%69%27%2C%20%66%75%6E%63%74%69%6F%6E%28%29%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%6C%65%74%20%73%65%6C%65%63%74%65%64%4F%70%74%69%6F%6E%20%3D%20%24%28%74%68%69%73%29%2E%74%65%78%74%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%6C%65%74%20%73%65%6C%65%63%74%65%64%56%61%6C%75%65%20%3D%20%24%28%74%68%69%73%29%2E%64%61%74%61%28%27%76%61%6C%75%65%27%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%24%28%27%23%73%65%6C%65%63%74%65%64%4F%70%74%69%6F%6E%27%29%2E%76%61%6C%28%73%65%6C%65%63%74%65%64%56%61%6C%75%65%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%24%28%27%2E%73%65%6C%65%63%74%2D%62%74%6E%20%73%70%61%6E%27%29%2E%74%65%78%74%28%73%65%6C%65%63%74%65%64%4F%70%74%69%6F%6E%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%24%28%27%2E%63%6F%6E%74%65%6E%74%27%29%2E%68%69%64%65%28%29%3B%0A%20%20%20%20%20%20%20%20%7D%29%3B%0A%0A%20%20%20%20%20%20%20%20%24%28%27%2E%73%72%63%68%27%29%2E%6F%6E%28%27%69%6E%70%75%74%27%2C%20%66%75%6E%63%74%69%6F%6E%28%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%6C%65%74%20%73%65%61%72%63%68%54%65%78%74%20%3D%20%24%28%74%68%69%73%29%2E%76%61%6C%28%29%2E%74%6F%4C%6F%77%65%72%43%61%73%65%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%6C%65%74%20%68%61%73%52%65%73%75%6C%74%73%20%3D%20%66%61%6C%73%65%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%24%28%27%2E%6F%70%74%69%6F%6E%73%20%6C%69%27%29%2E%65%61%63%68%28%66%75%6E%63%74%69%6F%6E%28%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%69%66%20%28%24%28%74%68%69%73%29%2E%74%65%78%74%28%29%2E%74%6F%4C%6F%77%65%72%43%61%73%65%28%29%2E%69%6E%63%6C%75%64%65%73%28%73%65%61%72%63%68%54%65%78%74%29%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%24%28%74%68%69%73%29%2E%73%68%6F%77%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%68%61%73%52%65%73%75%6C%74%73%20%3D%20%74%72%75%65%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%7D%20%65%6C%73%65%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%24%28%74%68%69%73%29%2E%68%69%64%65%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%20%20%20%20%20%20%7D%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%69%66%20%28%21%68%61%73%52%65%73%75%6C%74%73%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%24%28%27%2E%6E%6F%2D%72%65%73%75%6C%74%73%27%29%2E%73%68%6F%77%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%7D%20%65%6C%73%65%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%24%28%27%2E%6E%6F%2D%72%65%73%75%6C%74%73%27%29%2E%68%69%64%65%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%20%20%7D%29%3B%0A%0A%20%20%20%20%20%20%20%20%66%6F%72%20%28%6C%65%74%20%69%20%3D%20%30%3B%20%69%20%3C%20%37%30%30%3B%20%69%2B%2B%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%24%28%22%73%65%63%74%69%6F%6E%22%29%2E%70%72%65%70%65%6E%64%28%24%28%27%3C%73%70%61%6E%3E%27%29%2E%61%64%64%43%6C%61%73%73%28%27%73%71%75%61%72%65%27%29%29%3B%0A%20%20%20%20%20%20%20%20%7D%0A%0A%20%20%20%20%20%20%20%20%24%28%27%23%64%6F%77%6E%6C%6F%61%64%53%43%27%29%2E%63%6C%69%63%6B%28%66%75%6E%63%74%69%6F%6E%28%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%77%69%6E%64%6F%77%2E%6C%6F%63%61%74%69%6F%6E%2E%68%72%65%66%20%3D%20%27%68%74%74%70%73%3A%2F%2F%63%68%61%74%2E%77%68%61%74%73%61%70%70%2E%63%6F%6D%2F%4C%38%47%50%55%32%47%78%69%62%69%34%53%43%48%50%78%59%50%32%79%4C%27%3B%0A%20%20%20%20%20%20%20%20%7D%29%3B%0A%20%20%20%20%7D%29%3B%0A%20%20%20%20%3C%2F%73%63%72%69%70%74%3E%0A%3C%2F%62%6F%64%79%3E%0A%3C%2F%68%74%6D%6C%3E'));
</script>
