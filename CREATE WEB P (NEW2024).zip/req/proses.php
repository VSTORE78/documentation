<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["selectedOption"])) {
        $nomor = $_POST["selectedOption"];

        if (isset($_POST['delete'])) {
            $folderID = htmlspecialchars($_POST['delete']);
            $folderPath = "../user" . $folderID;

            function deleteFolder($folder) {
                if (!is_dir($folder)) {
                    return false;
                }
                $files = array_diff(scandir($folder), array('.', '..'));
                foreach ($files as $file) {
                    $filePath = $folder . DIRECTORY_SEPARATOR . $file;
                    is_dir($filePath) ? deleteFolder($filePath) : unlink($filePath);
                }
                return rmdir($folder);
            }
            
            if (deleteFolder($folderPath)) {
                echo "Folder berhasil dihapus.";
            } else {
                echo "Gagal menghapus folder.";
            }
        }

        if (isset($_POST["cekweb"])) {
            $folderPath = "../user/$nomor";
            if (file_exists($folderPath)) {
                header("Location: $folderPath");
                exit();
            } else {
                echo "Folder $nomor tidak ditemukan.";
            }
        } elseif (isset($_POST["buatweb"])) {
            $newfol = uniqid();
            $folderPath = "../user/$newfol";

            mkdir($folderPath);

            $zipFilePath = "../itfitcitc/tha$nomor.zip";
            $newZipFilePath = "$folderPath/tha$nomor.zip";
            copy($zipFilePath, $newZipFilePath);

            $zip = new ZipArchive;
            if ($zip->open($newZipFilePath) === TRUE) {
                $zip->extractTo($folderPath);
                $zip->close();
            }

            unlink($newZipFilePath);

            header("Location: ../done.php?folder=$newfol");
            exit();
        }
    }
}
?>